<?php
require_once 'partial/header.php';

include('backend/alert.php');

?>

<body>
    <main>
         <section class="w-100 h-100 mt-5">
                <section class="row col-md-10" style="justify-content-center; margin-left: 5vw; margin-top: 5vh; color: white;">
                    <article class="col-md-4 tekst justify-content-center">
                        <h1 style="font-size: 3rem;">Over ons</h1>
                            <p class="mt-5" style="font-size: 1.5rem;">Hobo is de perfecte streaming website die je maar kan gebruiken.
                            Zo bieden wij een enorme selectie aan de beste films van nu en toen.
                            Echter zijn een van de beste streaming servicen van heel Nederland en word onze catologus elke dag vernieuwd
                            met nieuwe films. Is er net een nieuwe film uit, maar wil je niet naar de bioscoop? Sluit nu dan een abbonoment aan bij Hobo
                            en ervaar de nieuwste films vanuit het comfort van je bank.
                            </p>
                </article>
                    <article class="col-md-6 col-sm-2 logofull"><img src="img/logo full.png" class="img-fluid" style="transform: rotate(35deg);">
                </article>
            </article>
        </section>
        </section>
    </main>
</body>

<?php
require_once 'partial/footer.php';
?>  